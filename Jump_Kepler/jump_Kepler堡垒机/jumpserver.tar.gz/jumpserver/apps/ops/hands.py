# ~*~ coding: utf-8 ~*~

from users.permissions import IsSuperUser
from users.utils import AdminUserRequiredMixin