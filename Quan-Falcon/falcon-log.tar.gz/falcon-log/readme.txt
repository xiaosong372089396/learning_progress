1.插件启动:
	.control start

2.配置文件详解:
		{ 
		 "logLevel": "DEBUG",
		  "metric": "logs",							
		  "timer": 30, 									#要同步数据间隔时间和上报数据的step值，api接口最小30，保持 30/60为好
		  "agent": "http://127.0.0.1:1988/v1/push",    #插件介意放在每一个agent上
		  "host": "agent-192.168.166.66",  			#主机名字，根据hostname设定，不要使用localhost，可能导致查询不到数据
		  "files": [
			{
			  "path": "/data/logs/test.log", 	#要监控的日志目录或者文件,如果是目录则会寻找其中一个匹配的日志文件,如果是文件,则会直接监控这个文件,但是不管如何,启动程序时候路径都要存在
			  "prefix": "test1",  				#要监控的日志文件名字前缀
			  "suffix": ".log",  				#要监控的日志文件后缀，如果不填则用默认值
			  "keywords": [      				#是 keyword对象数组
				{
				  "exp": "服务器下线test1", 	#1.支持中文
												#2.支持正则匹配
				  "tag": "ERROR"     			#对应于监控中tag的key,必须唯一
				}
			  ]
			},
			{
			  "path": "/data/logs/test2.log",
			  "prefix": "ceshi2",
			  "suffix": ".log",
			  "keywords": [
				{
				  "exp": "服务器下线test2",
				  "tag": "ERROR-2"
				}
			  ]
			}
		  ]
		}


3.在日志采集中，tags值必须写，不然没法捕捉进行报警。
	
	日志模板配置tags是由配置文件中的prefix 值和tag值拼接
	tags: prefix=test1,tag=ERROR
